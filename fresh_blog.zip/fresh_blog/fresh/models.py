from django.db import models
from django.utils import timezone
# from django.contrib.auth.models import User
# Create your models here.
class User(models.Model):
    Password = models.CharField(max_length=128)#密码
    Username = models.CharField(max_length=128)#用户
    Email = models.EmailField()#邮件
    Iocn = models.TextField(default='../static/img/uploads/avatar/avatar-58x58-default.png')#头像
    Occupation = models.CharField(max_length=128,default="游客")#职位
    QQ = models.CharField(max_length=12)#qq
    WeChat = models.CharField(max_length=22)#微信
    WeiBo = models.CharField(max_length=22)#微博
    Phone = models.CharField(max_length=11)#手机号码



class Article(models.Model):
    Image = models.TextField()#图片
    Title = models.CharField(max_length=122)#标题
    Time = models.DateTimeField(default=timezone.now)#日期
    Category = models.CharField(max_length=186)#类别
    NewTime = models.DateTimeField(auto_now=True)#修改日期
    Introduce = models.CharField(max_length=122)#介绍
    ProBody = models.TextField()#内容
    User = models.ForeignKey(User, on_delete=models.CASCADE)
class Comment(models.Model):
    Body = models.TextField()#评论内容
    Time = models.DateTimeField(auto_now_add=True)#评论日期
    Article =  models.ForeignKey(Article,on_delete=models.CASCADE)#评论用户
    User = models.ForeignKey(User,on_delete=models.CASCADE)#评论用户

class Portfolio(models.Model):
    Title = models.CharField(max_length=128)#标题
    Introduce = models.CharField(max_length=122)  # 介绍
    Category = models.CharField(max_length=186)  # 类别
    StartTime = models.DateTimeField(default=timezone.now)  # 日期
    EndTime = models.DateTimeField(auto_now=True)  # 修改日期
    ProUrl = models.TextField()#项目URL
    Image = models.TextField()#图片
    Body = models.TextField()#内容

