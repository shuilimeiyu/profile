from django.apps import AppConfig


class FreshConfig(AppConfig):
    name = 'fresh'
