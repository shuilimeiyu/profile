from django.shortcuts import render,redirect,HttpResponse
from fresh import models
from django.conf import settings
from django.core.paginator import Paginator
# Create your views here.
def personal(request):

    return render(request, 'personal.html', locals())
# def logon(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         password = request.POST['password']
#         email = request.POST['email']
#         User = models.User.objects.create(Username=username,Password=password,Email=email)
#     else:
#         message = "只能接受POST的连接！"
#     return render(request, 'logon.html', locals())
def login(request):
    if request.session.get('Login', None):
        return redirect('/category')
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        try:
            user = models.User.objects.get(Username=username)
            if user.Password == password:
                print(username)
                request.session['Login'] = True
                request.session['user_id'] = user.id
                request.session['user_username'] = user.Username
                print(request.session['user_id'])

                return redirect('/category/')
            else:
                message = "密码不正确！"
                return render(request, 'login.html', locals())
        except:
            message = "账号或者密码不正确！"
            return render(request, 'login.html', locals())
    else:
        print("请通过POST提交表单")

    return render(request, 'login.html', locals())
def logout(request):
    if not request.session.get('Login', None):
        # 如果本来就未登录，也就没有登出一说
        return redirect("/category/")
    request.session.flush()
    # 或者使用下面的方法
    # del request.session['is_login']
    # del request.session['user_id']
    # del request.session['user_name']
    return redirect("/category/")

def category(request):
    Blog = models.Article.objects.filter()
    count_comment = []
    for v in Blog:
        Comment_Article = models.Comment.objects.filter(Article_id=v.id)
        print(Comment_Article.count())
        count_comment.append(Comment_Article.count())
    print(count_comment)
    all = zip(Blog,count_comment)
    return render(request,'category.html',locals())
def portfolio(request):
    Portolio__ = models.Portfolio.objects.filter()
    return render(request,'portfolio.html',locals())
def Article(request,id):
    try:
        User = models.User.objects.get(id=request.session['user_id'])
        Blog = models.Article.objects.get(id=id)
        Comment = models.Comment.objects.filter(Article_id=id)
        if request.method == 'POST':
            body = request.POST['body']
            comment = models.Comment.objects.create(Body=body, User_id=request.session['user_id'], Article_id=id)
            return render(request, 'Article.html', locals())
        else:
            page = request.GET.get('page')
            paginator2 = Paginator(Comment, 6)
            Comment_page = paginator2.get_page(page)
            qian = Comment_page.number - 1
            hou = Comment_page.number + 1
            qian2 = Comment_page.number - 2
            hou2 = Comment_page.number + 2
            return render(request,'Article.html',locals())
    except:
        return HttpResponse("请你登录！你还没有登录")

def Add_Article(request):
    if request.method == "POST":
        if request.session.get('Login', None):
            Title = request.POST['Title']
            Category = request.POST['Category']
            Introduce = request.POST['Introduce']
            ProBody = request.POST['ProBody']
            file = request.FILES.get('picture', None)
            print(file)
            if file:
                fileDB = "../media/" + str(file)
                print(fileDB)
                F = settings.MEDIA_ROOT + '\\' + file.name
                with open(F, 'wb') as IOCN:
                    for c in file.chunks():
                        IOCN.write(c)
                        print(fileDB)
                        Article1= models.Article.objects.create(Image=fileDB,Title=Title,Category=Category,Introduce=Introduce,ProBody=ProBody,User_id=request.session['user_id'])
                        return redirect('/category/')
        else:
             return HttpResponse("抱歉你还没有登录，请登录！")

    else:
        return render(request, 'Article_add.html', locals())
    # if int(id)==1:
    #     Portfolio = models.Portfolio.objects.get()
    # Article = models.Article.objects.get()
    # User_id = User_information.objects.get(user_id=request.user.id)
    # if User_id.user_id_id == request.user.id:
    #     file = request.FILES.get('picture', None)
    #     if file:
    #         fileDB = "media/" + str(file)
    #         F = settings.MEDIA_ROOT + '\\' + file.name
    #         with open(F, 'wb') as IOCN:
    #             for c in file.chunks():
    #                 IOCN.write(c)
    #                 print("修改")
    #                 User_information.objects.filter(user_id_id=request.user.id).update(age=age, sex=sex,
    #                                                                                    autograph=autograph,
    #                                                                                    city=city, phone=phone,
    #                                                                                    iocn=fileDB,
    #                                                                                    user_id_id=request.user.id)
    #                 return redirect('/gerenziliao/')
    #
    #

