from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from App.models import User,Article
from django.contrib.auth.hashers import make_password
from django.core.paginator import Paginator
# Create your views here.
def index(request):
    page = 1
    xiaoqingxin = Article.objects.filter(columnl='小清新').order_by('id')
    xinxianshi = Article.objects.filter(columnl='新鲜事').order_by('id')
    xuexi = Article.objects.filter(columnl='学习').order_by('id')
    aiqing = Article.objects.filter(columnl='爱情').order_by('id')

    xiaoqingxin = Paginator(xiaoqingxin, 3)
    xiaoqingxin = xiaoqingxin.get_page(page)

    xinxianshi = Paginator(xinxianshi, 3)
    xinxianshi = xinxianshi.get_page(page)

    xuexi = Paginator(xuexi, 3)
    xuexi = xuexi.get_page(page)

    aiqing = Paginator(aiqing, 3)
    aiqing = aiqing.get_page(page)

    return render(request,'index.html',locals())
# def left_sidebar(request):
#     return render(request,'left-sidebar.html',locals())
# def no_sidebar(request):
#     return render(request, 'no-sidebar.html', locals())
# def right_sidebar(request):
#     return render(request, 'right-sidebar.html', locals())
def login__(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        if username and password:
            user = authenticate(username=username, password=password)
            if user is not None:
                # 将用户数据保存在 session 中，即实现了登录动作
                login(request, user)
                return redirect("/index/")
            else:
                message = "账号或者密码出错"
        else:
            message = "请输入账号或者密码"
    return render(request, 'login.html', locals())
def register(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        password2 = request.POST['password2']
        email = request.POST['email']
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']

        if password != password2:
            message = "两次输入的密码不同！"
            print(message)
            return render(request, 'register.html', locals())
        else:
            pd_username = User.objects.filter(username=username)
            if pd_username:
                message = "用户名已经存在！"
                print(message)
                return render(request, 'register.html', locals())
            pd_email = User.objects.filter(email=email)
            if pd_email:
                message = "邮箱已经存在！"
                print(message)
                return render(request, 'register.html', locals())
            mpwd = make_password(password, None, 'pbkdf2_sha256')
            User.objects.create(username=username, password=mpwd, email=email, first_name=first_name,last_name=last_name)
            return redirect('/login/')
    # User.objects.create_user('username','email.@qq.com','password')
    return render(request, 'register.html', locals())
def editor(request):

    return render(request, 'editor.html', locals())
def show(request):
    if request.method == 'POST':
        columnl = request.POST['columnl']
        body = request.POST['body']
        title = request.POST['title']
        if columnl == None and body == None and title == None:
            message = "你输入的内容不能为空！"
            return render(request,'editor.html',locals())
        else:
            print("成功插入！")
            ArticleUser = Article.objects.create(body=body,title=title,columnl=columnl,User_id_id=request.user.id)
            return render(request, 'show.html', locals())
def xinxianshi1(request,page):

    xinxianshi = Article.objects.filter(columnl='新鲜事')


    xinxianshi = Paginator(xinxianshi, 3)
    xinxianshi = xinxianshi.get_page(page)
    qian = xinxianshi.number - 1
    hou = xinxianshi.number + 1
    qian2 = xinxianshi.number - 2
    hou2 = xinxianshi.number + 2

    return render(request,'xinxianshi.html',locals())
def xiaoqingxin1(request,id):
    xiaoqingxin = Article.objects.filter(id=id)
    return render(request,'xiaoqingxin.html',locals())